import { Col, Container, Row } from 'react-bootstrap';
import './CheckDisease.css';
import Footer from '../Footer/Footer.jsx';
import Header2 from '../Header2/Header2.jsx';
import React, { useState } from 'react';
import axios from "axios";
import { ipofserver } from '../../../global.js';
import Select from 'react-select';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
/*eslint-disable eqeqeq*/
/* eslint-disable */

const CheckDisease = () => {

    const [isSearchable, setIsSearchable] = useState(true);
    const [isLoading, setIsLoading] = useState(true);

    const [value, setValue] = useState('');

    const colourOptions = [
        { value: '', label: 'Select gender' },
        { value: '1', label: 'Male' },
        { value: '0', label: 'Female' },
    ];

    const [selectedValue, setSelectedValue] = useState('');

    const handleChange = e => {
        setSelectedValue(e.value);
    }

    const [inputField, setInputField] = useState({
        patientname: 'Yash salvi',
        age: '23',
        urea: '34',
        creatinine: '44.7',
        hemoglobin: '56.3',
        cholesterol: '54',
        triglyceride: '78',
        highlipoprotein: '23',
        lowlipoprotein: '67.9',
        vlowlipoprotein: '56.4',
        bodymass: '78',
    })

    const [show, setShow] = useState(false);
    const handleClose = event => {
        setShow(false);
    }
    const handleShow = () => setShow(true);

    const inputsHandler = (e) => {
        const { name, value } = e.target;
        setInputField((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    function clearInput() {
        setInputField({
            patientname: '',
            age: '',
            urea: '',
            creatinine: '',
            hemoglobin: '',
            cholesterol: '',
            triglyceride: '',
            highlipoprotein: '',
            lowlipoprotein: '',
            vlowlipoprotein: '',
            bodymass: '',
        });
        setSelectedValue('')
    }

    const submitButton = async () => {
        if (inputField.patientname == '' || selectedValue == '' || inputField.age == ''
            || inputField.urea == '' || inputField.creatinine == '' || inputField.hemoglobin == ''
            || inputField.cholesterol == '' || inputField.triglyceride == '' || inputField.highlipoprotein == ''
            || inputField.lowlipoprotein == '' || inputField.vlowlipoprotein == '' || inputField.bodymass == '') {
            alert("Please enter all details !")
        }
        else {

            const formData = new FormData();

            formData.append('adminname', localStorage.getItem('LoginUsername'));
            formData.append('typeofuser', localStorage.getItem('LoginUsertype'));
            formData.append('patientname', inputField.patientname);
            formData.append('gender', selectedValue);
            formData.append('age', inputField.age);
            formData.append('urea', inputField.urea);
            formData.append('creatinine', inputField.creatinine);
            formData.append('hemoglobin', inputField.hemoglobin);
            formData.append('cholesterol', inputField.cholesterol);
            formData.append('triglyceride', inputField.triglyceride);
            formData.append('highlipoprotein', inputField.highlipoprotein);
            formData.append('lowlipoprotein', inputField.lowlipoprotein);
            formData.append('vlowlipoprotein', inputField.vlowlipoprotein);
            formData.append('bodymass', inputField.bodymass);

            const res = await axios.post(`${ipofserver}getPrediction`, formData);

            clearInput()
            if (res.data == "nodiabetes") {
                setValue('No diabetes detected !');
                handleShow();
            }
            else if (res.data == "predictivediabetes") {
                setValue('Predictive diabetes detected !');
                handleShow();
            }
            else if (res.data == "diabetes") {
                setValue('Diabetes detected !');
                handleShow();
            }
            else {
                setValue('Something went wrong !');
                handleShow();
            }
        }
    }

    return (
        <>
            <Header2 />
            <section className="appoinment-wrapper">
                <Container>
                    <Row>
                        <Col sm={12} md={12}>
                            <div className="section-title">
                                <h1 className="mt-5">Check Disease Prediction</h1>
                            </div>
                            <div className="appoinment-form row">
                                <h5 className='theme-btn btn-fill'>Enter Details</h5>

                                <Col md={12} lg={12}>
                                    <input type="text" placeholder="Enter patient full name"
                                        name="patientname" value={inputField.patientname} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>

                                <Col md={6} lg={6}>
                                    <Select
                                        className="basic-single selectclass"
                                        classNamePrefix="select"
                                        isLoading={isLoading}
                                        isSearchable={isSearchable}
                                        options={colourOptions}
                                        onChange={handleChange}
                                        value={colourOptions.find(obj => obj.value === selectedValue)}
                                        styles={{
                                            menu: provided => ({
                                                ...provided,
                                                zIndex: 9999, // Adjust this value as needed
                                            }),
                                        }}
                                    />
                                </Col>
                                <Col md={6} lg={6}>
                                    <input type="number" placeholder="Enter age"
                                        name="age" value={inputField.age} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter Urea level in the blood"
                                        name="urea" value={inputField.urea} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter Creatinine level in the blood"
                                        name="creatinine" value={inputField.creatinine} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter Hemoglobin A1c level"
                                        name="hemoglobin" value={inputField.hemoglobin} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter cholesterol level in the blood"
                                        name="cholesterol" value={inputField.cholesterol} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter Triglyceride level in the blood"
                                        name="triglyceride" value={inputField.triglyceride} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter High-density lipoprotein cholesterol"
                                        name="highlipoprotein" value={inputField.highlipoprotein} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter Low-density lipoprotein cholesterol "
                                        name="lowlipoprotein" value={inputField.lowlipoprotein} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter Very low-density lipoprotein cholesterol"
                                        name="vlowlipoprotein" value={inputField.vlowlipoprotein} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <Col md={12} lg={12}>
                                    <input type="number" placeholder="Enter Body Mass Index"
                                        name="bodymass" value={inputField.bodymass} onChange={inputsHandler}
                                        className="placeholder-black inputclass" />
                                </Col>
                                <button className="theme-btn btn-fill form-btn mt-3" onClick={submitButton}>Predict</button>
                            </div>
                        </Col>
                    </Row>

                    <Modal show={show} onHide={handleClose}
                        size="lg"
                        aria-labelledby="contained-modal-title-vcenter"
                        centered>
                        <Modal.Header closeButton>
                            <Modal.Title>Predicted Result</Modal.Title>
                        </Modal.Header>
                        <Modal.Body style={{ maxHeight: '400px', overflowY: 'auto' }}>
                            {value}
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant='primary' size="large" style={{ fontSize: '16px' }} onClick={handleClose}>Cancle</Button>
                        </Modal.Footer>
                    </Modal>
                </Container>
            </section>
            <Footer />
        </>
    );
};

export default CheckDisease;