const firebaseConfig = {
    apiKey: "AIzaSyC5ybdNyjFhzw2lw5L9r2laPycG5Mg_cHU",
    authDomain: "donto-8ab38.firebaseapp.com",
    projectId: "donto-8ab38",
    storageBucket: "donto-8ab38.appspot.com",
    messagingSenderId: "366989959436",
    appId: "1:366989959436:web:cc036f28966bd274866929"
  };
  
export default firebaseConfig;