export const FakeDoctors = [
    {
        "id": "001",
        "name": "Darry Milin",
        "status": "Oral Surgeon",
        "img": "https://i.ibb.co/pz92gsK/d1.png"
    },
    {
        "id": "002",
        "name": "Salman Ahmed",
        "status": "Oral Surgeon",
        "img": "https://i.ibb.co/yRcJ55b/d2.png"
    },
    {
        "id": "003",
        "name": "Santa Binte",
        "status": "Oral Surgeon",
        "img": "https://i.ibb.co/zJXZcqW/d3.png"
    }
]