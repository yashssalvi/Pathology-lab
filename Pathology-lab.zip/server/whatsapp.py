# from twilio.rest import Client

# account_sid = 'AC57c7f6bf70908b81181271f09107ee90'
# auth_token = 'a397ed6dae17a13846956b8656e44c98'
# client = Client(account_sid, auth_token)

# message = client.messages.create(
#   from_='+16672618689',
#   body='afasfasdasd',
#   to='+919930090883'
# )

# print(message.sid)


from twilio.rest import Client

account_sid = "AC57c7f6bf70908b81181271f09107ee90"
auth_token = "a397ed6dae17a13846956b8656e44c98"

client = Client(account_sid,auth_token)

from_whatapp_number = "whatsapp:+14155238886"

to_whatapp_number = "whatsapp:+919930090883"

message = client.messages.create(
    media_url='https://ba48-182-48-193-176.ngrok.io/tmp/a.pdf',
    # media_url=["https://www.irjmets.com/uploadedfiles/paper/issue_5_may_2022/23789/final/fin_irjmets1653211941.pdf"],
    from_=from_whatapp_number,
    to=to_whatapp_number
    )

print(message)