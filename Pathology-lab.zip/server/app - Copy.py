from flask import Flask,request 
import pymysql
from flask_cors import CORS

app = Flask(__name__)

UPLOAD_FOLDER = 'static/files/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

CORS(app)
app.secret_key = 'any random string'

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="Pathology")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()


"----------------------------------------------------------------------------------------------------"

@app.route('/userRegister', methods=['GET', 'POST'])
def userRegister():
    if request.method == 'POST':
        data = request.get_json()
        
        username = data.get('username')
        email = data.get('email')
        mobile = data.get('mobile')
        password = data.get('password')
        address = data.get('address')
        
        print(mobile)
        
        cursor.execute('SELECT * FROM userdetails WHERE username = %s', (username))
        count = cursor.rowcount
        if count == 1:        
            return "fail"
        else:
            sql1 = "INSERT INTO userdetails(username, email, mobile, password, address) VALUES (%s, %s, %s, %s, %s);"
            val1 = (username, email, mobile, password, address)
            cursor.execute(sql1,val1)
            con.commit()
            return "success"
        
        return "success"
    return "fail"
"----------------------------------------------------------------------------------------------------"

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.get_json()
        
        username = data.get('username')
        password = data.get('password')

        cursor.execute('SELECT * FROM userdetails WHERE  username=%s and  password=%s', (username, password))
        count = cursor.rowcount
        if count == 1:
            return "success"
        else:
            return "Fail"
        
"----------------------------------------------------------------------------------------------------"

@app.route('/adminlogin', methods=['GET', 'POST'])
def adminlogin():
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        print(username,password)
        cursor.execute('SELECT * FROM admin WHERE  username=%s and  password=%s', (username, password))
        count = cursor.rowcount
        if count == 1:
            return "success"
        else:
            return "Fail"        

    
if __name__ == "__main__":
    app.run("0.0.0.0")
    
    
